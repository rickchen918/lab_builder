# Terraform fish shell completion

Copy the completions to your local fish configuration:

```
mkdir -p ~/.config/fish/completions
cp terraform.fish ~/.config/fish/completions
```

Please note that these completions have been merged upstream and should be bundled with fish 2.6 or later.
