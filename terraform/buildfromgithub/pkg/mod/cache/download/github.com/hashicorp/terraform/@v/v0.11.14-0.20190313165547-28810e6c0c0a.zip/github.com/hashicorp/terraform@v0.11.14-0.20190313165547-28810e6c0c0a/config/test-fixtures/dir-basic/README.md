This file just exists to test that LoadDir doesn't load non-Terraform
files.
